# Pocket Doctor
**UXGreen/tendency · v1026**

A bilingual (EN/ES) medical app prototype with:
- Patient & Doctor dual-role flows
- Dose tracker with gamification (XP, streaks, levels)
- Per-dose alarm system with accomplishment panel
- Live translation bridge
- Prescription wizard (Rx)
- WCAG AA contrast compliant

## Deploy
Deployed via Vercel — static single-file app.

## Local preview
```
npx serve .
```
